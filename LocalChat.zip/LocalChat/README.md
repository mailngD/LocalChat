# LocalChat - 本地离线聊天应用

一个完全离线、无需注册的Android聊天应用，数据存储在手机本地。

## 功能特点

- ✅ 无需注册 - 输入昵称即可使用
- ✅ 完全离线 - 无需网络连接
- ✅ 本地存储 - 聊天记录保存在手机
- ✅ 虚拟ID - 自动生成唯一用户ID

## 一键在线编译

### 方法1：GitHub Actions（推荐）

1. **创建GitHub仓库**
   - 登录 https://github.com
   - 创建新仓库，上传本项目所有文件

2. **自动构建**
   - 推送代码后自动触发构建
   - 前往 Actions 查看构建状态
   - 下载生成的APK

3. **手动触发**
   - 进入仓库 → Actions → Build Android APK
   - 点击 "Run workflow"

### 方法2：使用在线IDE

**CodeSandbox:**
1. 打开 https://codesandbox.io/
2. 选择 "Android" 模板
3. 上传所有项目文件
4. 运行构建

### 方法3：使用在线APK生成器

1. **AppsGeyser** (https://appsgeyser.com/)
   - 注册账号
   - 选择 "Create App Now"
   - 选择 "APK File"
   - 上传项目文件

2. **Andromo** (https://andromo.com/)
   - 注册账号
   - 创建新项目
   - 导入Android项目

## 项目文件说明

```
LocalChat/
├── app/
│   ├── build.gradle          # App模块配置
│   └── src/main/
│       ├── AndroidManifest.xml
│       ├── java/com/localchat/app/
│       │   ├── LocalChatApp.java      # Application类
│       │   ├── LoginActivity.java     # 登录页面
│       │   ├── MainActivity.java      # 联系人列表
│       │   ├── ChatActivity.java      # 聊天页面
│       │   ├── LocalStorage.java      # 本地存储
│       │   ├── adapter/              # 适配器
│       │   └── model/                # 数据模型
│       └── res/                      # 资源文件
├── build.gradle              # 项目配置
├── settings.gradle
├── gradle.properties
├── local.properties          # SDK路径配置
├── gradlew.bat              # Gradle启动脚本
└── .github/workflows/build.yml  # 自动构建配置
```

## 使用说明

1. 安装APK后打开应用
2. 输入昵称，点击"开始聊天"
3. 系统自动生成虚拟ID（如 user_abc123）
4. 点击"我的ID"查看和复制您的ID
5. 同一设备测试：退出后用新昵称登录，添加之前生成的ID为联系人

## 技术栈

- Android SDK 34
- Java 8
- Material Design
- SharedPreferences 本地存储
- RecyclerView 列表

## 许可证

MIT License
