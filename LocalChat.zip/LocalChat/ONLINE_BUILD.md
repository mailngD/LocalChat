# LocalChat 在线编译指南

## 快速开始 - 使用在线编译服务

### 方法1：CodeSandbox (推荐)

1. 打开 https://codesandbox.io/
2. 注册/登录
3. 点击 "Create Sandbox" → 选择 "Android"
4. 上传本项目所有文件
5. 点击 "Build" 生成APK

### 方法2：GitHub + App Center

1. 将项目上传到GitHub
2. 打开 https://appcenter.ms/
3. 连接GitHub账号
4. 选择项目构建Android

### 方法3：本地安装Java后编译

```bash
# 1. 安装 JDK 17
# https://adoptium.net/

# 2. 安装 Android SDK Command Line Tools
# https://developer.android.com/studio#cmdline-tools

# 3. 编译APK
cd LocalChat
gradlew.bat assembleDebug

# APK生成位置: app\build\outputs\apk\debug\app-debug.apk
```

## 项目结构

```
LocalChat/
├── app/
│   ├── build.gradle
│   └── src/main/
│       ├── AndroidManifest.xml
│       ├── java/com/localchat/app/
│       │   ├── LocalChatApp.java
│       │   ├── LoginActivity.java
│       │   ├── MainActivity.java
│       │   ├── ChatActivity.java
│       │   ├── LocalStorage.java
│       │   ├── adapter/MessageAdapter.java
│       │   └── model/{User,Message,Contact}.java
│       └── res/
│           ├── layout/*.xml
│           ├── drawable/*.xml
│           └── values/colors.xml
├── build.gradle
├── settings.gradle
├── gradle.properties
├── local.properties
└── gradlew.bat
```

## 功能说明

- 无需注册，输入昵称即可
- 本地存储聊天记录
- 完全离线可用
- 无需任何网络服务
