package com.localchat.app;

import android.content.Context;
import android.content.SharedPreferences;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.localchat.app.model.Contact;
import com.localchat.app.model.Message;
import com.localchat.app.model.User;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 本地存储 - 使用SharedPreferences保存所有数据
 * 无需网络，数据完全保存在手机上
 */
public class LocalStorage {
    private static final String PREF_NAME = "localchat_prefs";
    private static final String KEY_USER = "current_user";
    private static final String KEY_CONTACTS = "contacts_list";
    private static final String KEY_MESSAGES = "messages_";
    
    private SharedPreferences prefs;
    private Gson gson;
    
    public LocalStorage(Context context) {
        prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        gson = new Gson();
    }
    
    // ===== 用户管理 =====
    public void saveUser(User user) {
        String json = gson.toJson(user);
        prefs.edit().putString(KEY_USER, json).apply();
    }
    
    public User getUser() {
        String json = prefs.getString(KEY_USER, null);
        if (json != null) {
            return gson.fromJson(json, User.class);
        }
        return null;
    }
    
    public void clearUser() {
        prefs.edit().remove(KEY_USER).apply();
    }
    
    public boolean isLoggedIn() {
        return getUser() != null;
    }
    
    // ===== 联系人管理 =====
    public void saveContacts(List<Contact> contacts) {
        String json = gson.toJson(contacts);
        prefs.edit().putString(KEY_CONTACTS, json).apply();
    }
    
    public List<Contact> getContacts() {
        String json = prefs.getString(KEY_CONTACTS, null);
        if (json != null) {
            Type type = new TypeToken<List<Contact>>(){}.getType();
            return gson.fromJson(json, type);
        }
        return new ArrayList<>();
    }
    
    public void addContact(Contact contact) {
        List<Contact> contacts = getContacts();
        // 检查是否已存在
        for (Contact c : contacts) {
            if (c.getId().equals(contact.getId())) {
                return;
            }
        }
        contacts.add(contact);
        saveContacts(contacts);
    }
    
    public void removeContact(String contactId) {
        List<Contact> contacts = getContacts();
        contacts.removeIf(c -> c.getId().equals(contactId));
        saveContacts(contacts);
        // 同时删除与该联系人的聊天记录
        prefs.edit().remove(KEY_MESSAGES + contactId).apply();
    }
    
    // ===== 消息管理 =====
    public void saveMessages(String contactId, List<Message> messages) {
        String json = gson.toJson(messages);
        prefs.edit().putString(KEY_MESSAGES + contactId, json).apply();
    }
    
    public List<Message> getMessages(String contactId) {
        String json = prefs.getString(KEY_MESSAGES + contactId, null);
        if (json != null) {
            Type type = new TypeToken<List<Message>>(){}.getType();
            return gson.fromJson(json, type);
        }
        return new ArrayList<>();
    }
    
    public void addMessage(String contactId, Message message) {
        List<Message> messages = getMessages(contactId);
        messages.add(message);
        saveMessages(contactId, messages);
        
        // 更新联系人的最后消息
        List<Contact> contacts = getContacts();
        for (Contact c : contacts) {
            if (c.getId().equals(contactId)) {
                c.setLastMessage(message.getContent());
                c.setLastChatTime(message.getTimestamp());
                break;
            }
        }
        saveContacts(contacts);
    }
}
