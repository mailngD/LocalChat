package com.localchat.app.model;

/**
 * 联系人模型
 */
public class Contact {
    private String id;
    private String nickname;
    private String note;
    private long lastChatTime;
    private String lastMessage;
    
    public Contact() {}
    
    public Contact(String id, String nickname) {
        this.id = id;
        this.nickname = nickname;
        this.lastChatTime = System.currentTimeMillis();
    }
    
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    
    public String getNickname() { return nickname; }
    public void setNickname(String nickname) { this.nickname = nickname; }
    
    public String getNote() { return note; }
    public void setNote(String note) { this.note = note; }
    
    public long getLastChatTime() { return lastChatTime; }
    public void setLastChatTime(long lastChatTime) { this.lastChatTime = lastChatTime; }
    
    public String getLastMessage() { return lastMessage; }
    public void setLastMessage(String lastMessage) { this.lastMessage = lastMessage; }
    
    @Override
    public String toString() {
        return nickname + " (" + id + ")";
    }
}
