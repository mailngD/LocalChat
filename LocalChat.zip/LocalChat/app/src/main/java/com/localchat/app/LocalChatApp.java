package com.localchat.app;

import android.app.Application;

/**
 * LocalChat - 纯本地离线聊天应用
 * 无需网络，数据存储在手机本地
 */
public class LocalChatApp extends Application {
    
    @Override
    public void onCreate() {
        super.onCreate();
    }
}
