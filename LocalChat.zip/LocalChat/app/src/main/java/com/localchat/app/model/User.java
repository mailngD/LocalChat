package com.localchat.app.model;

import java.util.UUID;

/**
 * 本地用户模型
 */
public class User {
    private String id;
    private String nickname;
    private long createdAt;
    
    public User() {
        this.createdAt = System.currentTimeMillis();
    }
    
    public User(String nickname) {
        this.id = generateId();
        this.nickname = nickname;
        this.createdAt = System.currentTimeMillis();
    }
    
    public static String generateId() {
        return "user_" + UUID.randomUUID().toString().substring(0, 6);
    }
    
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    
    public String getNickname() { return nickname; }
    public void setNickname(String nickname) { this.nickname = nickname; }
    
    public long getCreatedAt() { return createdAt; }
    public void setCreatedAt(long createdAt) { this.createdAt = createdAt; }
    
    @Override
    public String toString() {
        return nickname + " (" + id + ")";
    }
}
