package com.localchat.app.model;

/**
 * 消息模型
 */
public class Message {
    private String id;
    private String senderId;
    private String senderName;
    private String receiverId;
    private String content;
    private long timestamp;
    private boolean isSent;
    
    public Message() {
        this.timestamp = System.currentTimeMillis();
    }
    
    public Message(String senderId, String senderName, String receiverId, String content) {
        this.id = System.currentTimeMillis() + "_" + (int)(Math.random() * 10000);
        this.senderId = senderId;
        this.senderName = senderName;
        this.receiverId = receiverId;
        this.content = content;
        this.timestamp = System.currentTimeMillis();
        this.isSent = true;
    }
    
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    
    public String getSenderId() { return senderId; }
    public void setSenderId(String senderId) { this.senderId = senderId; }
    
    public String getSenderName() { return senderName; }
    public void setSenderName(String senderName) { this.senderName = senderName; }
    
    public String getReceiverId() { return receiverId; }
    public void setReceiverId(String receiverId) { this.receiverId = receiverId; }
    
    public String getContent() { return content; }
    public void setContent(String content) { this.content = content; }
    
    public long getTimestamp() { return timestamp; }
    public void setTimestamp(long timestamp) { this.timestamp = timestamp; }
    
    public boolean isSent() { return isSent; }
    public void setSent(boolean sent) { isSent = sent; }
}
