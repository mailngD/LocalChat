package com.localchat.app;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import com.localchat.app.model.Contact;
import com.localchat.app.model.User;
import java.util.ArrayList;
import java.util.List;

/**
 * 主页面 - 联系人列表
 */
public class MainActivity extends AppCompatActivity {
    
    private ListView listView;
    private ArrayAdapter<String> adapter;
    private List<String> displayList;
    private LocalStorage localStorage;
    private User currentUser;
    private List<Contact> contacts;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        localStorage = new LocalStorage(this);
        currentUser = localStorage.getUser();
        
        if (currentUser == null) {
            goToLogin();
            return;
        }
        
        initViews();
    }
    
    @Override
    protected void onResume() {
        super.onResume();
        loadContacts();
    }
    
    private void initViews() {
        listView = findViewById(R.id.list_friends);
        
        displayList = new ArrayList<>();
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, displayList);
        listView.setAdapter(adapter);
        
        setTitle("LocalChat - " + currentUser.getNickname());
        
        // 点击进入聊天
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if (position < contacts.size()) {
                    Contact contact = contacts.get(position);
                    startChat(contact);
                }
            }
        });
        
        // 长按删除
        listView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                if (position < contacts.size()) {
                    showDeleteDialog(position);
                }
                return true;
            }
        });
        
        loadContacts();
    }
    
    private void loadContacts() {
        contacts = localStorage.getContacts();
        displayList.clear();
        
        for (Contact contact : contacts) {
            String info = contact.getNickname() + "\n" + contact.getLastMessage();
            displayList.add(info);
        }
        
        adapter.notifyDataSetChanged();
    }
    
    public void showAddContactDialog(View view) {
        final EditText inputName = new EditText(this);
        inputName.setHint("对方昵称");
        
        final EditText inputId = new EditText(this);
        inputId.setHint("对方ID（如 user_abc123）");
        
        android.widget.LinearLayout layout = new android.widget.LinearLayout(this);
        layout.setOrientation(android.widget.LinearLayout.VERTICAL);
        layout.setPadding(50, 20, 50, 10);
        layout.addView(inputName);
        layout.addView(inputId);
        
        new AlertDialog.Builder(this)
            .setTitle("添加联系人")
            .setMessage("在同一设备上测试：\n可以添加自己生成的另一个ID")
            .setView(layout)
            .setPositiveButton("添加", (dialog, which) -> {
                String name = inputName.getText().toString().trim();
                String id = inputId.getText().toString().trim();
                
                if (name.isEmpty() || id.isEmpty()) {
                    Toast.makeText(this, "请填写完整信息", Toast.LENGTH_SHORT).show();
                    return;
                }
                
                Contact contact = new Contact(id, name);
                localStorage.addContact(contact);
                loadContacts();
                Toast.makeText(this, "已添加联系人", Toast.LENGTH_SHORT).show();
            })
            .setNegativeButton("取消", null)
            .show();
    }
    
    private void showDeleteDialog(int position) {
        Contact contact = contacts.get(position);
        new AlertDialog.Builder(this)
            .setTitle("删除联系人")
            .setMessage("确定删除 " + contact.getNickname() + " 吗？\n聊天记录也将删除")
            .setPositiveButton("删除", (dialog, which) -> {
                localStorage.removeContact(contact.getId());
                loadContacts();
                Toast.makeText(this, "已删除", Toast.LENGTH_SHORT).show();
            })
            .setNegativeButton("取消", null)
            .show();
    }
    
    private void startChat(Contact contact) {
        Intent intent = new Intent(this, ChatActivity.class);
        intent.putExtra("contact_id", contact.getId());
        intent.putExtra("contact_name", contact.getNickname());
        startActivity(intent);
    }
    
    private void goToLogin() {
        Intent intent = new Intent(this, LoginActivity.class);
        startActivity(intent);
        finish();
    }
    
    public void showMyId(View view) {
        new AlertDialog.Builder(this)
            .setTitle("我的信息")
            .setMessage("昵称: " + currentUser.getNickname() + "\n\n" +
                       "ID: " + currentUser.getId() + "\n\n" +
                       "在同一设备上测试：\n1. 退出登录\n2. 用不同昵称重新登录\n3. 添加刚才的ID为联系人")
            .setPositiveButton("复制ID", (dialog, which) -> {
                android.content.ClipboardManager clipboard = (android.content.ClipboardManager) 
                    getSystemService(CLIPBOARD_SERVICE);
                android.content.ClipData clip = android.content.ClipData.newPlainText(
                    "LocalChat ID", currentUser.getId());
                clipboard.setPrimaryClip(clip);
                Toast.makeText(this, "已复制", Toast.LENGTH_SHORT).show();
            })
            .setNegativeButton("关闭", null)
            .show();
    }
    
    public void logout(View view) {
        new AlertDialog.Builder(this)
            .setTitle("退出登录")
            .setMessage("确定退出吗？")
            .setPositiveButton("退出", (dialog, which) -> {
                localStorage.clearUser();
                goToLogin();
            })
            .setNegativeButton("取消", null)
            .show();
    }
}
