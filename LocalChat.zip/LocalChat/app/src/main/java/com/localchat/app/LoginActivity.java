package com.localchat.app;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.localchat.app.model.User;

/**
 * 登录页面 - 纯本地，无需注册
 */
public class LoginActivity extends AppCompatActivity {
    
    private EditText etNickname;
    private Button btnEnter;
    private TextView tvTip;
    private LocalStorage localStorage;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        
        localStorage = new LocalStorage(this);
        
        // 检查是否已登录
        if (localStorage.isLoggedIn()) {
            goToMain();
            return;
        }
        
        initViews();
    }
    
    private void initViews() {
        etNickname = findViewById(R.id.et_nickname);
        btnEnter = findViewById(R.id.btn_enter);
        tvTip = findViewById(R.id.tv_tip);
        
        tvTip.setText("本地聊天应用\n数据保存在手机上\n无需注册，输入昵称即可");
        
        btnEnter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String nickname = etNickname.getText().toString().trim();
                
                if (nickname.isEmpty()) {
                    Toast.makeText(LoginActivity.this, "请输入昵称", Toast.LENGTH_SHORT).show();
                    return;
                }
                
                if (nickname.length() < 2) {
                    Toast.makeText(LoginActivity.this, "昵称至少2个字符", Toast.LENGTH_SHORT).show();
                    return;
                }
                
                // 创建本地用户
                User user = new User(nickname);
                localStorage.saveUser(user);
                
                Toast.makeText(LoginActivity.this, 
                    "欢迎 " + nickname + "！\n您的ID: " + user.getId(), 
                    Toast.LENGTH_LONG).show();
                
                goToMain();
            }
        });
    }
    
    private void goToMain() {
        Intent intent = new Intent(LoginActivity.this, MainActivity.class);
        startActivity(intent);
        finish();
    }
}
