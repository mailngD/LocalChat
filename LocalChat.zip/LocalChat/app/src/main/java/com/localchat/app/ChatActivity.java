package com.localchat.app;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.localchat.app.adapter.MessageAdapter;
import com.localchat.app.model.Message;
import com.localchat.app.model.User;
import java.util.ArrayList;
import java.util.List;

/**
 * 聊天页面 - 完全本地存储
 */
public class ChatActivity extends AppCompatActivity {
    
    private ListView listView;
    private EditText etMessage;
    private Button btnSend;
    private MessageAdapter adapter;
    private List<Message> messages = new ArrayList<>();
    
    private LocalStorage localStorage;
    private User currentUser;
    private String contactId;
    private String contactName;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat);
        
        localStorage = new LocalStorage(this);
        currentUser = localStorage.getUser();
        
        if (currentUser == null) {
            finish();
            return;
        }
        
        contactId = getIntent().getStringExtra("contact_id");
        contactName = getIntent().getStringExtra("contact_name");
        
        if (contactId == null || contactName == null) {
            Toast.makeText(this, "参数错误", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }
        
        initViews();
        loadMessages();
    }
    
    private void initViews() {
        listView = findViewById(R.id.list_messages);
        etMessage = findViewById(R.id.et_message);
        btnSend = findViewById(R.id.btn_send);
        
        TextView tvTitle = findViewById(R.id.tv_title);
        tvTitle.setText(contactName);
        
        adapter = new MessageAdapter(this, messages, currentUser.getId());
        listView.setAdapter(adapter);
        
        btnSend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendMessage();
            }
        });
    }
    
    private void sendMessage() {
        String content = etMessage.getText().toString().trim();
        if (content.isEmpty()) {
            return;
        }
        
        // 创建发送的消息
        Message message = new Message(
            currentUser.getId(),
            currentUser.getNickname(),
            contactId,
            content
        );
        
        // 保存到本地
        localStorage.addMessage(contactId, message);
        messages.add(message);
        adapter.notifyDataSetChanged();
        scrollToBottom();
        
        etMessage.setText("");
        
        // 模拟收到回复（用于测试）
        simulateReply(content);
    }
    
    /**
     * 模拟回复 - 用于单设备测试
     * 在实际使用中，这个方法不会被调用
     */
    private void simulateReply(String content) {
        Toast.makeText(this, "消息已发送\n（对方不在线，测试模式下不会收到回复）", Toast.LENGTH_SHORT).show();
    }
    
    private void loadMessages() {
        messages.clear();
        List<Message> saved = localStorage.getMessages(contactId);
        messages.addAll(saved);
        adapter.notifyDataSetChanged();
        scrollToBottom();
    }
    
    private void scrollToBottom() {
        if (messages.size() > 0) {
            listView.setSelection(messages.size() - 1);
        }
    }
}
